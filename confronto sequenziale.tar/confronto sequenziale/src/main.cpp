// main.cpp  (CPU-only)
// Versione CPU: niente CUDA, niente NVCC.
// Mantiene la stessa CLI di prima (ma --gpu viene ignorato).

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

#include "../include/config.h"
#include "../include/database_loader.h"
#include "../include/research_types.h"
#include "../include/frame_research.h"
#include "../include/I_O/winner_frame.h"

// ------------------------------------------------------------
// Timer RAII (debug)
// ------------------------------------------------------------
struct ScopedTimer {
  std::string name;
  std::chrono::high_resolution_clock::time_point t0;

  explicit ScopedTimer(std::string n)
      : name(std::move(n)), t0(std::chrono::high_resolution_clock::now()) {}

  ~ScopedTimer() {
    auto t1 = std::chrono::high_resolution_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    std::cout << "[TIMER] " << name << ": " << ms << " ms\n";
  }
};

// ------------------------------------------------------------
// CLI parsing
// ------------------------------------------------------------
static void print_usage(const char* prog) {
  std::cout
      << "Usage:\n"
      << "  " << prog << " <full-db_PATH> <frame_PATH> [options]\n"
      << "Notes:\n"
      << "  The deduplicated DB will be written to: ./newDB (relative to current working directory)\n"
      << "Options:\n"
      << "  --verbose               Logging verboso\n"
      << "  --topk <k>              Numero candidati per template matching (fase query)\n"
      << "  --dedup-threshold <t>   SAD threshold for frame deduplication (fase build)\n"
      << "  --gpu <id>              (IGNORED in CPU-only build)\n";
}

static bool is_flag(const std::string& s, const char* f) { return s == f; }

static int to_int_or_die(const std::string& s, const char* what) {
  char* end = nullptr;
  long v = std::strtol(s.c_str(), &end, 10);
  if (!end || *end != '\0') {
    std::cerr << "Invalid integer for " << what << ": " << s << "\n";
    std::exit(2);
  }
  return static_cast<int>(v);
}

static Config parse_args(int argc, char** argv) {
  Config cfg;

  // two positional args: full db path + frame path
  if (argc < 3) {
    print_usage(argv[0]);
    std::exit(0);
  }

  cfg.full_db_path     = argv[1];
  cfg.query_frame_path = argv[2];

  // default output for deduplicated db: ./newDB (cwd)
  std::filesystem::path cwd = std::filesystem::current_path();
  std::filesystem::path out = cwd / "newDB";
  cfg.deduplicated_db_path = out.string();
  std::filesystem::create_directories(out);

  // options start from argv[3]
  for (int i = 3; i < argc; ++i) {
    std::string a = argv[i];

    if (is_flag(a, "--help") || is_flag(a, "-h")) {
      print_usage(argv[0]);
      std::exit(0);
    } else if (is_flag(a, "--gpu")) {
      // CPU-only: manteniamo l'opzione per compatibilità, ma la ignoriamo.
      if (++i >= argc) { std::cerr << "--gpu needs a value\n"; std::exit(2); }
      cfg.gpu_id = to_int_or_die(argv[i], "--gpu"); // letto ma ignorato
    } else if (is_flag(a, "--verbose")) {
      cfg.verbose = true;
    } else if (is_flag(a, "--topk")) {
      if (++i >= argc) { std::cerr << "--topk needs a value\n"; std::exit(2); }
      cfg.topk = to_int_or_die(argv[i], "--topk");
    } else if (is_flag(a, "--dedup-threshold")) {
      if (++i >= argc) { std::cerr << "--dedup-threshold needs a value\n"; std::exit(2); }
      cfg.dedup_threshold = to_int_or_die(argv[i], "--dedup-threshold");
    } else {
      std::cerr << "Unknown arg: " << a << "\n";
      std::exit(2);
    }
  }

  if (cfg.topk <= 0) {
    std::cerr << "--topk must be > 0\n";
    std::exit(2);
  }
  if (cfg.dedup_threshold <= 0) {
    std::cerr << "--dedup-threshold must be > 0\n";
    std::exit(2);
  }

  return cfg;
}

// ------------------------------------------------------------
// main
// ------------------------------------------------------------
int main(int argc, char** argv) {
  ScopedTimer total("total_time_program: ");
  Config cfg = parse_args(argc, argv);

  if (cfg.verbose) {
    std::cout << "\nINFORMAZIONI GENERALI ==================================================\n";
    std::cout << "[CPU] Build CPU-only (CUDA disabled)\n";
    std::cout << "[CFG] full_db_path=" << cfg.full_db_path << "\n";
    std::cout << "[CFG] query_frame_path=" << cfg.query_frame_path << "\n";
    std::cout << "[CFG] deduplicated_db_path=" << cfg.deduplicated_db_path << "\n";
    std::cout << "[CFG] topk=" << cfg.topk << "\n";
    std::cout << "[CFG] dedup_threshold=" << cfg.dedup_threshold << "\n";
    std::cout << "[CFG] --gpu ignored (value read=" << cfg.gpu_id << ")\n";
  }

  try {
    {
      BuildStats st = carica_db(cfg);

      if (cfg.verbose) {
        std::cout << "\n[BUILD DONE] frames_total=" << st.frames_total
                  << " frames_after_dedup=" << st.frames_after_dedup
                  << " signatures_written=" << st.signatures_written << "\n";
      }
    }

    QueryResult r = ricerca_frame(cfg);

    // salvo il frame vincitore
    dump_winner_frame_ppm(cfg, r, "winner.ppm");
    std::cout << "Saved winner.ppm\n";

  } catch (const std::exception& e) {
    std::cerr << "[FATAL] Exception: " << e.what() << "\n";
    return 1;
  }

  return 0;
}
